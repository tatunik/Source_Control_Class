# Test Automation University Course
## Source Control for Test Automation with Git
This is the project template for following along my TAU course [Source Control for Test Automation with Git](https://testautomationu.applitools.com/instructors/simon_berner.html).
Feel free to create your own project and then use that one. If you choose to use this project, consider to
download this repo as zip and not to clone it (otherwise the upstream repo will be already set). Once you have it locally, you can then setup your own remote
repository e.g. on GitHub.

If you want know more about the exciting moment when this course got released, [read my blog post](https://simonberner.rocks/2020/07/10/Released-My-First-Online-Course-on-TAU-0/)! 🙂

Have fun with my course! 🥳