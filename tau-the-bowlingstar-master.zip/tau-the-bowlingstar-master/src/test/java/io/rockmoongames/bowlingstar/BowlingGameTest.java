package io.rockmoongames.bowlingstar;

import org.junit.jupiter.api.Test;

public class BowlingGameTest {

    @Test
    public void jessicaTestOne() {

    }
}
